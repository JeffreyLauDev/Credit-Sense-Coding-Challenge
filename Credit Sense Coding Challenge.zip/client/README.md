# Getting Started with Credit Sense Technical server 
## Installation Scripts
    $ yarn

## Start & watch
    $ cd client
    $ yarn start
