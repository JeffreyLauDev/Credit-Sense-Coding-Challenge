# Getting Started with Credit Sense Technical server 
## Installation Scripts
    $ npm install

## Start & watch
    $ cd server
    $ npm start
